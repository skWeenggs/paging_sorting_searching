const { response } = require("express");
const express = require("express");
const { MongoTopologyClosedError } = require("mongodb");

const mongoose = require("mongoose");
const User = require("./model/Post");
// const userRouter= require("./Routes/Routes")
const cors=require('cors');
require("dotenv").config();

const app = express();

app.use(express.json());





app.use(cors());


const PORT = 3800;

const uri = process.env.MONGO_DB;

// app.get("/", (req, res) => {
//   res.send("have connected!");
// });

mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const connection = mongoose.connection;
connection.once("open", () => {
  console.log("connection has established with mongoDB");
});

mongoose.connection.on("disconnected",()=>{
  console.log("Mogoodb connection disconnected");
})

//INSERT


app.post("/add", async (req, res) => {

  try {
    console.log("req.body", req.body);

    const { name, email, contact_no, message, status, gender, city } = req.body;

    const newUser = new User({
      name,
      email,
      contact_no,
      message,
      status,
      gender,
      city,
    });

    await User.create(newUser);

    res.send(newUser);
  } catch (err) {
    console.log("error", err);
    res.status(500).json({error:true,massage:"Internal Server Error"});
  }
});


// app.delete('users/:id',async(req,res)=>{
//   try{
//     await User.findByIdAndDelete(req.params.id);
//     res.status(200).json({
//       status:'success',
//       data:null
//     });
//   }catch(err){
//     res.status(404).json({
//       status:'fail',
//       massage: err
//     })
//   }
// })

//PAGING GET USERS

// app.use('/',userRouter)

app.get("/users", paginatedresult(User), (req, res) => {
  res.json(res.paginatedResults);
});

function paginatedresult(model) {
  return async (req, res, next) => {
    const page = parseInt(req.query.page); //    .../page=2
    const limit = parseInt(req.query.limit, 5) || 5; // .../limit=10

    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    const name_ = req.query.name; // .../name=ashmita
    const city_ = req.query.city; // .../city=rajkot

    const filter =
    name_ && city_
      ? { name: { $regex: name_ }, city: { $regex: city_ } }
      : name_
      ? { name: { $regex: name_ } }
      : city_
      ? { city: { $regex: city_ } }
      : {};

  const results = {};

    if (endIndex < (await model.countDocuments().exec())) {
      results.next = {
        page: page + 1,
        limit: limit,
      };
    }

    if (startIndex > 0) {
      results.previous = {
        page: page - 1,
        limit: limit,
      };
    }
    try {
      results.results = await model
        .find(filter)
        .limit(limit)
        .skip(startIndex)
        .sort({
          name: 1,
        })
        .exec();
      res.paginatedResults = results;
      next();
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  };
}

app.get("/users/:key",async(req,res)=>{

  let data=await User.find(
    {
      "$or":[
        {name:{$regex:req.params.key}},
        {city:{$regex:req.params.key}},
        {email:{$regex:req.params.key}},
        // {gender:{$regex:req.params.key}},
        {message:{$regex:req.params.key}}
      ]
    }
  )
  res.send(data);
});




//SORTING

app.get("/users/sort/name/:key", async (req, res) => {
  if(req.params.key=== "asc"){

    let sortData = await User.find().sort({
      name: 1,
    });
    console.log(sortData);
    res.send(sortData);
  }
  else{

    let sortData = await User.find().sort({
      name: -1,
    });
    console.log(sortData);
    res.send(sortData);
  }

});

app.get("/users/sort/email/:key", async (req, res) => {
  if(req.params.key=== "asc"){

    let sortData = await User.find().sort({
      email: 1,
    });
    console.log(sortData);
    res.send(sortData);
  }
  else{

    let sortData = await User.find().sort({
      email: -1,
    });
    console.log(sortData);
    res.send(sortData);
  }

});



app.listen(PORT, () => {
  console.log("server is running on:", PORT);
  //* connecting database
});
