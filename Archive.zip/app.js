const { response } = require("express");
const express = require("express");
const { MongoTopologyClosedError } = require("mongodb");

const mongoose = require("mongoose");
const User = require("./model/Post");
const userRouter= require("./Routes/Routes")
const cors=require('cors');
require("dotenv").config();

const app = express();

app.use(express.json());





app.use(cors());


const PORT = 3800;

const uri = process.env.MONGO_DB;

app.get("/", (req, res) => {
  res.send("have connected!");
});

mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const connection = mongoose.connection;
connection.once("open", () => {
  console.log("connection has established with mongoDB");
});

mongoose.connection.on("disconnected",()=>{
  console.log("Mogoodb connection disconnected");
})

//INSERT

app.post("/add", async (req, res) => {

  try {
    console.log("req.body", req.body);

    const { name, email, contact_no, message, status, gender, city } = req.body;

    const newUser = new User({
      name,
      email,
      contact_no,
      message,
      status,
      gender,
      city,
    });

    await User.create(newUser);

    res.send(newUser);
  } catch (err) {
    console.log("error", err);
    res.status(500).json({error:true,massage:"Internal Server Error"});
  }
});

//PAGING GET USERS

app.use("/api",userRouter)

app.get("/users", paginatedresult(User), (req, res) => {
  res.json(res.paginatedResults);
});

function paginatedresult(model) {
  return async (req, res, next) => {
    const page = parseInt(req.query.page);
    const limit = parseInt(req.query.limit);

    const startIndex = (page + 1) * limit;
    const endIndex = page * limit;

    const results = {};

    if (endIndex < (await model.countDocuments().exec())) {
      results.next = {
        page: page + 1,
        limit: limit,
      };
    }

    if (startIndex > 0) {
      results.previous = {
        page: page - 1,
        limit: limit,
      };
    }
    try {
      results.results = await model.find().limit(limit).skip(startIndex).exec();
      res.paginatedResults = results;
      next();
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  };
}

//SEARCH

app.get("/search", async (req, res) => {
  /*const filters = req.query;
  const filteredUsers = post.filter((Users) => {
    let isValid = true;
    for (key in filters) {
      console.log(key, user[key], filters[key]);
      isValid = isValid && user[key] == filters[key];
    }
    return isValid;
  });
  res.send(filteredUsers);*/

  // let data = await User.find({
  //   $or: [
  //     { name: req.query.name && { $regex: req.query.name } },
  //     { email: req.query.email && { $regex: req.query.email } },
  //     // { contact_no: { $regex: req.params.key } },
  //     // { message: { $regex: req.params.key } },
  //     // { status: { $regex: req.params.key } },
  //     // { gender: { $regex: req.params.key } },
  //     { city: req.query.city && { $regex: req.query.city } },
  //   ],
  // });
  const name_ = req.query.name;
  const city_ = req.query.city;
  const filter =
    name_ && city_
      ? { name: { $regex: name_ }, city: { $regex: city_ } }
      : name_
      ? { name: { $regex: name_ } }
      : city_
      ? { city: { $regex: city_ } }
      : {};
  let data = await User.find(filter);

  console.log(data);
  res.send(data);
});

//SORTING

app.get("/sort", async (req, res) => {
  let sortData = await User.find().sort({
    name: -1,
  });
  console.log(sortData);
  res.send(sortData);
});

app.listen(PORT, () => {
  console.log("server is running on:", PORT);
  //* connecting database
});
